const express=require('express');
const router = express.Router();
const {findUser, saveUsers,validateUsers,updateUsers,deleteUsers,searchUsers} = require('../service/v1/user');


router.post('/updateId/:id', (req, res) => {
    const id = req.params.id;
    const body = req.body;
    updateUsers(id, body).then((data) => {
      
      res.redirect('/users/');
    }).catch((err) => {
      res.send(err);
    });
  });


  router.get('/deleteId/:id', (req, res) => {
    const id = req.params.id;
    deleteUsers(id).then((data) => {
      console.log
      res.redirect('/users/');
    }).catch((err) => {
      res.send(err);
    });
  });
  


router.post('/postData',(req,res)=>{
    console.log('######### req #########', req.body);
    saveUsers(req.body).then((data)=>{
        res.send(data);
    }).catch((error)=>{
        res.send(error);
    });
});

router.get('/', (req, res) => {
    findUser().then((data)=>{
        res.send(data);
    })
 });


 router.get('/searchId/:id', (req, res) => {
    const id = req.params.id;
    searchUsers(id).then((data) => {
      res.send(data);
    }).catch((err) => {
      res.send(err);
    });
  });



 router.get('/check',(req,res)=>{
    for(const key in req.query){
        console.log(key," : ",req.query[key])
    }
        const id = req.query.id;
        const password=req.query.password;
        validateUsers(id,password) .then((data)=>{
            if(data.length!=0)
            {
                res.status(200).send("Success ->  UserId and Password Exits");              //200 = Request Executed successfully
                console.log("Success ->  UserId and Password Exits");
                return;
            }
            else
            {
               //res.status(204).send("Fail ->  UserId or Password Does Not Exits");          //204= No Content
               res.status(204).json({ error: 'Fail ->  UserId or Password Does Not Exits' });
                console.log("Fail ->  UserId or Password Does Not Exits");
                return;
            }
        }).catch((err)=>{
            res.send(err);
            console.log(err);

        });
 });
 


module.exports=router;