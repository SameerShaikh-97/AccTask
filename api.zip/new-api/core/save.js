const User = require('../models').User;
class Save
{
    saveUser(body)
    {
        return new Promise((resolve, reject) => {
            User.create({
                name: body.name,
                password: body.password,
                state:body.state,
                mobileno: body.mobileno,
            }).then((data)=>{
                resolve(data);
            }).catch((err)=>{
                // console.error(err);
                reject(err);
            });
        });
    }
}

module.exports = {
    SaveClass: Save,
};