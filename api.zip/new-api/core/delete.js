const User = require('../models').User

class Delete { 
    deleteUser(id){
        // console.log(body);
        return new Promise((resolve, reject) => {
            User.destroy({
                where: {
                  id: id
                }
              }).then((data)=>{
                resolve(data)
            }).catch((err)=>{
                // console.error(err);
                reject(err)
            });
        });
    }
}

module.exports = {
    DeleteClass: Delete,
};