const User = require('../models').User;
class Find{
    findAll(){
        return new Promise((resolve,reject)=>{
            User.findAll().then((data)=>{
                console.log('data : ', data);
                resolve(data)
            }).catch((err)=>{
                reject(err)
            });
        });
    }
}

module.exports = {
    FindClass: Find,
};